const form = document.getElementById("expenseForm");
const list = document.getElementById("expenseList");
const totalText = document.getElementById("totalExpenses");
const countText = document.getElementById("countExpenses");

let expenses = [];

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const description = document.getElementById("description").value;
  const amount = Number(document.getElementById("amount").value);
  const category = document.getElementById("category").value;
  const date = document.getElementById("date").value;

  const expense = {
    id: Date.now(),
    description: description,
    amount: amount,
    category: category,
    date: date,
  };

  expenses.push(expense);

  showExpenses();
  updateStats();
  saveData();

  form.reset();
});

function showExpenses() {
  list.innerHTML = "";

  for (let i = 0; i < expenses.length; i++) {
    const exp = expenses[i];

    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${exp.description}</td>
      <td>${exp.category}</td>
      <td>${exp.amount}</td>
      <td>${exp.date}</td>
      <td><button onclick="deleteExpense(${exp.id})">Delete</button></td>
    `;

    list.appendChild(row);
  }
}

function deleteExpense(id) {
  expenses = expenses.filter(function (exp) {
    return exp.id !== id;
  });

  showExpenses();
  updateStats();
  saveData();
}

function updateStats() {
  let total = 0;

  for (let i = 0; i < expenses.length; i++) {
    total = total + expenses[i].amount;
  }

  totalText.textContent = total;
  countText.textContent = expenses.length;
}

function saveData() {
  localStorage.setItem("expenses", JSON.stringify(expenses));
}

function loadData() {
  const data = localStorage.getItem("expenses");

  if (data) {
    expenses = JSON.parse(data);
    showExpenses();
    updateStats();
  }
}

loadData();

const buttons = document.querySelectorAll(".filters button");

buttons.forEach(function (btn) {
  btn.addEventListener("click", function () {
    const filter = btn.getAttribute("data-filter");

    list.innerHTML = "";

    for (let i = 0; i < expenses.length; i++) {
      if (filter === "all" || expenses[i].category === filter) {
        const row = document.createElement("tr");

        row.innerHTML = `
          <td>${expenses[i].description}</td>
          <td>${expenses[i].category}</td>
          <td>${expenses[i].amount}</td>
          <td>${expenses[i].date}</td>
          <td><button onclick="deleteExpense(${expenses[i].id})">Delete</button></td>
        `;

        list.appendChild(row);
      }
    }
  });
});
